/******************************************************************************************************/
   NAME:       PLSQL Anonymous Block
   PURPOSE:    Transact Campus Assesment
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        05/08/2021   Suja 		   1. Created this Block.

   NOTES: This block written and executed in Oracle 19C Database

/******************************************************************************************************/

SET SERVEROUTPUT ON

DECLARE
    low    NUMBER;
    high   NUMBER;
    a      NUMBER;
    b      NUMBER;
    lv_output_A VARCHAR2 (100);
    lv_output_B VARCHAR2 (100);
BEGIN
    FOR r_seq IN (
        SELECT sequence FROM ( SELECT level  AS sequence FROM dual
                CONNECT BY level <=:high )
        WHERE sequence BETWEEN :low AND :high ) 
    LOOP
    DBMS_OUTPUT.PUT_LINE(r_seq.sequence);
    END LOOP;
    
FOR r_seq IN (
        SELECT sequence FROM ( SELECT level  AS sequence FROM dual
                CONNECT BY level <=:high )
        WHERE sequence BETWEEN :low AND :high ) 
    LOOP
    
      lv_output_A :=REMAINDER(r_seq.sequence, :A  ) ;        
       lv_output_B :=REMAINDER(r_seq.sequence, :B  )  ;
     
         IF   lv_output_A = 0 then 
         DBMS_OUTPUT.PUT_LINE(r_seq.sequence || ' - Fancy');
         ELSIF lv_output_B = 0 then
         DBMS_OUTPUT.PUT_LINE(r_seq.sequence || ' - Pants');
         ELSIF lv_output_A =0 and lv_output_B =0 then
         DBMS_OUTPUT.PUT_LINE(r_seq.sequence ||' - FancyPants');
         END IF;
    END LOOP;
END; 
/



